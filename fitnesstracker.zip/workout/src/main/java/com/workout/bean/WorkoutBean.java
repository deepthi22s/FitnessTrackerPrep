package com.workout.bean;

import javax.persistence.Entity;
import javax.persistence.Id;
import javax.persistence.Table;
import javax.persistence.Transient;

import org.springframework.stereotype.Component;

@Entity
@Component
public class WorkoutBean {
	@Id
	String workoutName;
		
	public String getWorkoutName() {
		return workoutName;
	}
	public void setWorkoutName(String workoutName) {
		this.workoutName = workoutName;
	}
	public String getWorkoutDescription() {
		return workoutDescription;
	}
	public void setWorkoutDescription(String workoutDescription) {
		this.workoutDescription = workoutDescription;
	}	
	public Integer getAverageCalorieBurn() {
		return averageCalorieBurn;
	}
	public void setAverageCalorieBurn(Integer averageCalorieBurn) {
		this.averageCalorieBurn = averageCalorieBurn;
	}
	public Integer getWorkoutTime() {
		return workoutTime;
	}
	public void setWorkoutTime(Integer workoutTime) {
		this.workoutTime = workoutTime;
	}
	public Integer getCaloriesBurnedByUser() {
		return caloriesBurnedByUser;
	}
	public void setCaloriesBurnedByUser(Integer caloriesBurnedByUser) {
		this.caloriesBurnedByUser = caloriesBurnedByUser;
	}
	
	String workoutDescription;
	Integer averageCalorieBurn;
	Integer workoutTime;
	@Transient  //Not to be included in table
	Integer caloriesBurnedByUser;
}
